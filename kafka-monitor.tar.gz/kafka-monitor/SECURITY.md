# Security Policy

## Supported Versions



| Version | Supported          |
| ------- | ------------------ |
| 1.1.x   | :white_check_mark: |



## Reporting a Vulnerability

Use this section to tell people how to report a vulnerability.

Please report a vulnerability on issues at https://github.com/linkedin/kafka-monitor/issues/new.
